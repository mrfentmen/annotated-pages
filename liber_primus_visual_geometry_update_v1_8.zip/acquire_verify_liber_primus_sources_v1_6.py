#!/usr/bin/env python3
"""
Acquire and byte-verify original Liber Primus page JPEGs against a recorded
GitHub source manifest.

Default target pages: 24, 40, 57, 68, 73.
This tool does not infer cipher meaning and does not treat GitHub directory
metadata as a substitute for hashing the acquired bytes.

Usage:
  python acquire_verify_liber_primus_sources_v1_6.py
  python acquire_verify_liber_primus_sources_v1_6.py --all-pages
  python acquire_verify_liber_primus_sources_v1_6.py --pages 24 40 73 --image-dir ./liber_primus_source_images_v1_6
  python acquire_verify_liber_primus_sources_v1_6.py --self-test
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from PIL import Image

DEFAULT_MANIFEST = "liber_primus_visual_source_integrity_v1_4.json"
DEFAULT_PAGES = (24, 40, 57, 68, 73)
EXPECTED_SIZE = (2400, 3600)
USER_AGENT = "LiberPrimusResearch/1.6 (source-integrity verification)"


def git_blob_sha1(data: bytes) -> str:
    """Compute Git's object SHA-1 for a blob, including its header."""
    header = f"blob {len(data)}\0".encode("ascii")
    return hashlib.sha1(header + data).hexdigest()


def load_manifest(path: Path) -> dict[str, Any]:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    required = {"repository", "ref", "directory", "pages", "expected_page_count"}
    missing = required - set(manifest)
    if missing:
        raise ValueError(f"Manifest missing required keys: {sorted(missing)}")
    if not isinstance(manifest["pages"], list):
        raise ValueError("Manifest field 'pages' must be a list.")
    return manifest


def page_index(manifest: dict[str, Any]) -> dict[int, dict[str, Any]]:
    result: dict[int, dict[str, Any]] = {}
    for row in manifest["pages"]:
        page = int(row["page"])
        sha = str(row["git_blob_sha1"]).lower()
        filename = str(row["filename"])
        if page in result:
            raise ValueError(f"Duplicate page index in manifest: {page}")
        if len(sha) != 40 or any(ch not in "0123456789abcdef" for ch in sha):
            raise ValueError(f"Invalid Git blob SHA-1 for page {page}: {sha}")
        result[page] = {"page": page, "filename": filename, "git_blob_sha1": sha}
    expected = int(manifest["expected_page_count"])
    if len(result) != expected:
        raise ValueError(f"Manifest has {len(result)} pages; expected {expected}.")
    return result


def source_url(manifest: dict[str, Any], filename: str) -> str:
    owner_repo = str(manifest["repository"]).strip("/")
    ref = str(manifest["ref"]).strip("/")
    directory = str(manifest["directory"]).strip("/")
    return f"https://raw.githubusercontent.com/{owner_repo}/{ref}/{directory}/{filename}"


def validate_image_bytes(data: bytes) -> tuple[bool, str, list[int] | None]:
    try:
        import io
        with Image.open(io.BytesIO(data)) as im:
            fmt = im.format
            size = list(im.size)
            im.verify()
        if fmt != "JPEG":
            return False, f"Unexpected image format: {fmt!r}", size
        if tuple(size) != EXPECTED_SIZE:
            return False, f"Unexpected dimensions: {size}, expected {list(EXPECTED_SIZE)}", size
        return True, "JPEG decoded; dimensions match expected source raster", size
    except Exception as exc:
        return False, f"Image decode/verification failed: {type(exc).__name__}: {exc}", None


def acquire_one(
    manifest: dict[str, Any],
    row: dict[str, Any],
    image_dir: Path,
    timeout: float,
) -> dict[str, Any]:
    page = int(row["page"])
    path = image_dir / row["filename"]
    url = source_url(manifest, row["filename"])
    expected_sha = row["git_blob_sha1"]
    report: dict[str, Any] = {
        "page": page,
        "filename": row["filename"],
        "source_url": url,
        "expected_git_blob_sha1": expected_sha,
        "output_path": str(path),
        "download_attempted": False,
    }

    data: bytes | None = None
    if path.exists():
        candidate = path.read_bytes()
        observed = git_blob_sha1(candidate)
        if observed == expected_sha:
            data = candidate
            report["reused_existing_file"] = True
        else:
            report["existing_file_rejected"] = True
            report["existing_git_blob_sha1"] = observed

    if data is None:
        report["download_attempted"] = True
        request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        try:
            with urllib.request.urlopen(request, timeout=timeout) as response:
                data = response.read()
                report["http_status"] = getattr(response, "status", None)
        except (urllib.error.URLError, TimeoutError, OSError) as exc:
            report.update({
                "status": "BLOCKED_DOWNLOAD",
                "error": f"{type(exc).__name__}: {exc}",
                "measurement_allowed": False,
            })
            return report

    report["byte_length"] = len(data)
    observed_sha = git_blob_sha1(data)
    report["observed_git_blob_sha1"] = observed_sha
    report["git_blob_sha1_matches"] = observed_sha == expected_sha
    report["sha256"] = hashlib.sha256(data).hexdigest()

    if observed_sha != expected_sha:
        report.update({
            "status": "BLOCKED_HASH_MISMATCH",
            "measurement_allowed": False,
        })
        return report

    valid, note, dimensions = validate_image_bytes(data)
    report["decode_validation"] = note
    report["dimensions_px"] = dimensions
    if not valid:
        report.update({
            "status": "BLOCKED_IMAGE_VALIDATION",
            "measurement_allowed": False,
        })
        return report

    if not path.exists() or path.read_bytes() != data:
        path.write_bytes(data)
    report.update({
        "status": "VERIFIED_SOURCE_IMAGE",
        "measurement_allowed": True,
    })
    return report


def self_test() -> int:
    assert git_blob_sha1(b"") == "e69de29bb2d1d6434b8b29ae775ad8c2e48c5391"
    print(json.dumps({
        "self_test": "PASS",
        "checks": [
            "Git blob SHA-1 includes the required 'blob <size>\\0' header.",
            "Known empty Git blob digest matches.",
        ],
        "scope": "Hashing helper only; no network access or manuscript pixels tested.",
    }, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--manifest", default=str(Path(__file__).resolve().with_name(DEFAULT_MANIFEST)),
                        help="Path to the v1.4 source integrity JSON (defaults to the script folder).")
    parser.add_argument("--image-dir", default="liber_primus_source_images_v1_6",
                        help="Directory to store verified JPEGs and the audit JSON.")
    parser.add_argument("--pages", nargs="+", type=int, default=list(DEFAULT_PAGES),
                        help="Page numbers to acquire, e.g. --pages 24 40 73.")
    parser.add_argument("--all-pages", action="store_true",
                        help="Acquire all pages 00.jpg through 74.jpg.")
    parser.add_argument("--timeout", type=float, default=20.0,
                        help="Per-request timeout in seconds.")
    parser.add_argument("--self-test", action="store_true",
                        help="Run a local hash-helper test without network access.")
    args = parser.parse_args()

    if args.self_test:
        return self_test()

    manifest_path = Path(args.manifest)
    if not manifest_path.exists():
        parser.error(f"Manifest not found: {manifest_path}")
    manifest = load_manifest(manifest_path)
    indexed = page_index(manifest)
    page_numbers = sorted(indexed) if args.all_pages else sorted(set(args.pages))
    invalid = sorted(set(page_numbers) - set(indexed))
    if invalid:
        parser.error(f"Pages absent from manifest: {invalid}")

    image_dir = Path(args.image_dir)
    image_dir.mkdir(parents=True, exist_ok=True)
    results = [
        acquire_one(manifest, indexed[page], image_dir, args.timeout)
        for page in page_numbers
    ]
    verified = sum(r.get("status") == "VERIFIED_SOURCE_IMAGE" for r in results)
    audit = {
        "version": "1.6",
        "created_utc": datetime.now(timezone.utc).isoformat(),
        "repository": manifest["repository"],
        "ref": manifest["ref"],
        "manifest_path": str(manifest_path),
        "requested_pages": page_numbers,
        "expected_raster": {"width": EXPECTED_SIZE[0], "height": EXPECTED_SIZE[1]},
        "verified_count": verified,
        "requested_count": len(page_numbers),
        "source_pixels_measured": False,
        "results": results,
        "interpretation": (
            "This script validates source byte identity and JPEG decoding only. "
            "It does not compute centroids, geometric significance, or cipher relevance."
        ),
    }
    audit_path = image_dir / "source_acquisition_audit_v1_6.json"
    audit_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    print(json.dumps({
        "verified": verified,
        "requested": len(page_numbers),
        "audit_path": str(audit_path),
        "results": [{
            "page": r["page"], "status": r.get("status"),
            "sha256": r.get("sha256"), "error": r.get("error"),
        } for r in results],
    }, indent=2))
    return 0 if verified == len(page_numbers) else 2


if __name__ == "__main__":
    sys.exit(main())
