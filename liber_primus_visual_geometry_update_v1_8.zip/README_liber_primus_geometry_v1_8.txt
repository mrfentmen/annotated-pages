Liber Primus Visual Geometry Update v1.8
==========================================

Contents
--------
- liber_primus_visual_master_dataset_v1_8.xlsx
  Updated master workbook, preserving prior sheets and adding Shape Controls v1.8.
- LIBER_PRIMUS_VISUAL_GEOMETRY_RESEARCH_v1_8.md
  Report with harmonized signature results, qualitative browser-source notes, and limitations.
- liber_primus_shape_controls_audit_v1_8.json
  Machine-readable audit of the results and provenance.
- analyze_liber_primus_shape_controls_v1_8.py
  Script that recomputes normalized shape signatures from the workbook's inherited coordinates.
- liber_primus_visual_master_dataset_v1_7.xlsx
  Canonical input workbook used by the analysis script.
- liber_primus_visual_source_integrity_v1_4.json
  Existing source-object manifest.
- acquire_verify_liber_primus_sources_v1_6.py
  Source acquisition and hash-verification script. It does not perform the geometric extraction itself.
- source_acquisition_audit_v1_6.json
  Prior record of the failed local download attempt.

Reproduce the shape-control calculation
---------------------------------------
Use Python with artifact_tool installed, in a directory containing the v1.7 workbook:

    python analyze_liber_primus_shape_controls_v1_8.py       --workbook liber_primus_visual_master_dataset_v1_7.xlsx       --output liber_primus_shape_controls_audit_v1_8.reproduced.json

The script is intentionally offline and computes from inherited workbook coordinates. It does not validate or decode source JPEG bytes and does not perform statistical inference.

Source-pixel validation status
------------------------------
Local requests to raw.githubusercontent.com and api.github.com failed with DNS name-resolution errors in this session. Browser-rendered raw images were reviewed qualitatively, but the JPEG bytes were not transferred into the local analysis filesystem. The input manifest's Git blob hashes therefore have NOT been recomputed from locally acquired source bytes in this update.

The next required step is to run the source-acquisition script in an environment with network access (or supply the original pages locally), validate Git blob SHA-1 and SHA-256, confirm JPEG dimensions, and reproduce the centroids using an independent JPEG decoder.
