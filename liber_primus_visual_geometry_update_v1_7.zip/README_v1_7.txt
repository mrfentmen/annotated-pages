Liber Primus Visual Geometry Investigation — v1.7 update

Primary artifact:
- liber_primus_visual_master_dataset_v1_7.xlsx
  Retains all v1.6 sheets and adds Threshold Match v1.7, with 12 summary rows and 60 point-level formula-backed records.

Research/audit artifacts:
- LIBER_PRIMUS_VISUAL_GEOMETRY_RESEARCH_v1_7.md
- liber_primus_threshold_match_audit_v1_7.json
- analyze_liber_primus_threshold_match_v1_7.py

Source acquisition support:
- liber_primus_source_acquisition_bundle_v1_6.zip
  Contains the original-source acquisition/verification script and v1.4 source-integrity manifest.

Evidence limitation:
The v1.7 threshold analysis recalculates stored Pixel Thresholds v1.1 records. It does not re-download or decode original JPEG bytes. It is descriptive only; there is no manuscript-specific inferential p-value or cipher conclusion. The local source-download attempts remain blocked by DNS resolution failure.

Reproduce the threshold audit (requires artifact_tool, plus the v1.6 workbook in the same directory):
  python analyze_liber_primus_threshold_match_v1_7.py --workbook liber_primus_visual_master_dataset_v1_6.xlsx --output liber_primus_threshold_match_reproduction_v1_7.json

The source acquisition bundle has separate instructions for running the verified image downloader from a network-enabled environment.
