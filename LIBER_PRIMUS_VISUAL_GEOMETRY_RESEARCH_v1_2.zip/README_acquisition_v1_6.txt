Liber Primus source-image acquisition bundle v1.6

Contents
- acquire_verify_liber_primus_sources_v1_6.py
- liber_primus_visual_source_integrity_v1_4.json

Prerequisites
- Python 3.10 or newer
- Pillow installed: python -m pip install Pillow
- Network access to raw.githubusercontent.com

Run in a terminal from any working directory:
  python /path/to/acquire_verify_liber_primus_sources_v1_6.py

The manifest is resolved relative to the script, so keep the two supplied files in the same folder. By default the script attempts pages 24, 40, 57, 68, and 73 and writes verified JPEGs under ./liber_primus_source_images_v1_6 (relative to the current working directory). It creates source_acquisition_audit_v1_6.json in that directory.

To acquire all 75 pages:
  python /path/to/acquire_verify_liber_primus_sources_v1_6.py --all-pages

To test only the Git blob SHA-1 helper without network access:
  python /path/to/acquire_verify_liber_primus_sources_v1_6.py --self-test

The script verifies the Git blob SHA-1 against the manifest, records SHA-256, and checks JPEG decoding and 2400 x 3600 dimensions. A verified download is not itself a centroid measurement. The bundled source manifest is inherited from the v1.4 source-integrity inventory.
